import os, signal, subprocess32 as subprocess
import osquery
from flask import Flask
from flask import jsonify
from flask import request

def consulta(query):
        instance = osquery.SpawnInstance()
        instance.open()
        result = instance.client.query(query)
        return result.response

def ejecutarComando(command):
        return os.system(command)

def matarProceso(processId):
        try:
            os.kill(processId, signal.SIGKILL)
            return 0
        except OSError:
            return 1


#Usuarios
def usuariosLogeados():
    return jsonify({"users": consulta("SELECT * FROM users")})

def usuariosLogeadosID(userId):
    return jsonify({"users": consulta("SELECT * FROM users WHERE uid = {0}".format(userId))})

def agregarUsuario():
	jsonBody = request.get_json(force=True)
	if ejecutarComando("useradd -p {0} {1}".format(jsonBody['userName'], jsonBody['userPass'])) == 0:
		return "Se creo el usuario"
	else:
		return "No se pudo crear el usuario"
    

def eliminarUsuario(userName):
	if ejecutarComando("deluser {0}".format(userName)) == 0:
		return "Se elimino el usuario"
	else: return "No se pudo eliminar el usuario"

#Prcoesos
def procesos():
    return jsonify({"processes": consulta("SELECT * FROM processes")})

def procesoID(processId):
    return jsonify({"processes": consulta("SELECT * FROM processes WHERE pid = {0}".format(processId))})

def eliminarProceso(processId):
    if matarProceso(processId) == 0:
        return "Proceso Borrado"
    else:
        return "No se pudo eliminar el proceso"

#Sistema operativo
def osVersion():
    return jsonify({"os_version": consulta("SELECT version FROM os_version")})

def kernelVersion():
    return jsonify({"kernel_version": consulta("SELECT version FROM kernel_info")})

def CapacidadMemoria():
    return jsonify({"memory": consulta("SELECT memory_total FROM memory_info")})

#Paquetes
def paquetesInstalados():
    return jsonify({"installed_packages": consulta("SELECT * FROM deb_packages")})

def paqueteInstalado(packageName):
    if ejecutarComando("apt-get install -y {0}".format(packageName))==0:
        return "Se instalo el paquete"
    else:
        return "No se pudo instalar el paquete"

def eliminarPaquete(packageName):
    if ejecutarComando("apt-get remove -y {0}".format(packageName))==0:
        "Se desinstalo el paquete"
    else:
        return "No se pudo desinstalar el paquete"


def init_api_routes(app):
    if app:
        app.add_url_rule('/api/users/','usuariosLogeados', usuariosLogeados, methods=['GET'])
        app.add_url_rule('/api/users/<string:userId>','usuariosLogeadosID', usuariosLogeadosID, methods=['GET'])
        app.add_url_rule('/api/users/','agregarUsuario', agregarUsuario, methods=['POST'])
        app.add_url_rule('/api/users/<string:userName>','eliminarUsuario', eliminarUsuario, methods=['DELETE'])
        app.add_url_rule('/api/processes/','procesos', procesos, methods=['GET'])
        app.add_url_rule('/api/processes/<string:processId>','procesoID', procesoID, methods=['GET'])
        app.add_url_rule('/api/processes/<int:processId>','eliminarProceso', eliminarProceso, methods=['DELETE'])
        app.add_url_rule('/api/os/','osVersion', osVersion, methods=['GET'])
        app.add_url_rule('/api/kernel/','kernelVersion', kernelVersion, methods=['GET'])
        app.add_url_rule('/api/memory/','CapacidadMemoria', CapacidadMemoria, methods=['GET'])
        app.add_url_rule('/api/packages/','paquetesInstalados', paquetesInstalados, methods=['GET'])
        app.add_url_rule('/api/packages/<string:packageName>','paqueteInstalado', paqueteInstalado, methods=['POST'])
        app.add_url_rule('/api/packages/<string:packageName>','eliminarPaquete', eliminarPaquete, methods=['DELETE'])




	    

#@app.route('/')
app=Flask(__name__)
init_api_routes(app)
app.run()