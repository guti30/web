### Required packages

1. pip install flask
1. pip install mysql-python
1. pip install sqlalchemy
1. pip install PyLD
